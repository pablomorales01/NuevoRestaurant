<?php
/**
 * Global defination for CDetailView
 */
return array(
	'default'=>array(
		'cssFile'=>Yii::app()->baseUrl.'/css/skins/detailview/styles.css',
	)
);