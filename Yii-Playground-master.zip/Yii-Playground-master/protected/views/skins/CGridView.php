<?php
/**
 * Global defination for CGridView
 */
return array(
	'default'=>array(
		'cssFile'=>Yii::app()->baseUrl.'/css/skins/gridview/styles.css',
	)
);