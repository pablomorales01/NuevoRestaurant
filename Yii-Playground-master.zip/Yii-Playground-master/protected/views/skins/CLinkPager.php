<?php
/**
 * Global defination for CLinkPager
 */
return array(
	'default'=>array(
		'header'=>'',
		'firstPageLabel'=>'&lt;&lt;',
		'prevPageLabel'=>'&lt;',
		'nextPageLabel'=>'&gt;',
		'lastPageLabel'=>'&gt;&gt;',
		'cssFile'=>Yii::app()->baseUrl.'/css/skins/pager/pager.css',
	)
);