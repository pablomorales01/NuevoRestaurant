<?php
/**
 * Global defination for CListView
 */
return array(
	'default'=>array(
		'cssFile'=>Yii::app()->baseUrl.'/css/skins/listview/styles.css',
	)
);