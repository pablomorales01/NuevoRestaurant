<?php
/**
 * Global defination for CTabView
 */
return array(
	'default'=>array(
		'cssFile'=>Yii::app()->baseUrl.'/css/skins/yiitab/yiitab.css',
	)
);